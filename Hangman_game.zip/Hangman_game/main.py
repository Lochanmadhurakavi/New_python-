from Hangman_art import *
from Hangman_words import *
import random

print("Welcome to Hangman Game!")
print(logo)
computer_word = random.choice(word_list)
word_list = [n for n in computer_word]
print("".join(word_list))
blanks = ["_" for n in range(len(word_list))]
print(" ".join(blanks))
lives = 6

is_game_on = True
while is_game_on:
    user_choice = input("Guess a letter:").lower()
    if user_choice in blanks:
        print("You have already guessed the word.")

    for position in range(len(word_list)):
        if word_list[position] == user_choice:
            blanks[position] = user_choice
    if user_choice in word_list:
        print("You guessed it right.")
        print("".join(blanks))
        print(stages[lives])
    if user_choice not in word_list:
        lives -= 1
        if lives == 0:
            print(stages[lives])
            print("You lost all of your lives")
            is_game_on = False
        else:
            print("You lose a life")
            print("".join(blanks))
            print(stages[lives])

    if "_" not in blanks:
        print("You won the game")
        is_game_on = False



